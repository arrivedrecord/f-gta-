# GTA V STATIC HTML

This project aims to convert the entire [Grand-V](https://github.com/SebasKitten/Grand-V) project into a single **standalone HTML file**. This means no more needing "mirror.rar" or downloading multiple separate files to get everything working.

The goal is to make the GTA V web port accessible directly through your browser, with support for GitHub Pages and other static HTML hosting services. Simply host the HTML file and run it without needing a backend server or additional setup.

The project is completely open source, meaning anyone can view the code, contribute, suggest improvements, or make their own modifications. Updates and improvements will be released regularly as development continues.

# How do I use this?
To use this you need a static website hoster, then copy or download [this](https://github.com/Truf-Porter/HTMLgta/blob/main/index.html) and then host it, and boom done.
